package com.annathe.SpringDataJPADMLDemo;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.annathe.ormlearn.SpringDataJpadmlDemoApplication;
import com.annathe.ormlearn.model.Message;
import com.annathe.ormlearn.repository.MessageRepository;
import com.annathe.ormlearn.service.MessageService;

@SpringBootTest(classes = SpringDataJpadmlDemoApplication.class)
@RunWith(MockitoJUnitRunner.class)
class SpringDataJpadmlDemoApplicationTests {

	
	@Mock
	private MessageRepository messageRepositoryMock;
	
	@InjectMocks
	private MessageService messageService;
	
	
	
	//@Autowired
	//private MessageService  messageService;
	
	
	
	  @Test 
	  public void testGetMessageContainsHello() {
	  
	  
	  Message message1 = new Message(); message1.setText("be happy");
	  
	  Message message2 = new Message(); message2.setText("Hello");
	  
	  Message message3 = new Message(); message3.setText("be yourself");
	  
	  List<Message> messages = new ArrayList<Message>();
	  
	  messages.add(message1);
	  messages.add(message2);
	  messages.add(message3);
	  
	  when(messageRepositoryMock.findAll()).thenReturn(messages);
	  
	  
	  
	  assertEquals(1,messageService.getMessageContainsHello().size());
	  
	  
	  }
	 


	
	/*
	 * @Test public void testGetMessageContainsHello() {
	 * 
	 * 
	 * assertEquals(2,messageService.getMessageContainsHello().size());
	 * 
	 * 
	 * 
	 * }
	 */



}
