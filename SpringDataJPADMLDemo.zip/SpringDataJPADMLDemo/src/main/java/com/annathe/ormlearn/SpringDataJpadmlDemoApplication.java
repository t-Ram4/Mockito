package com.annathe.ormlearn;

import java.util.List;
import java.util.Optional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.annathe.ormlearn.model.Message;
import com.annathe.ormlearn.repository.MessageRepository;
import com.annathe.ormlearn.service.MessageService;

import javassist.bytecode.Descriptor.Iterator;



@SpringBootApplication
public class SpringDataJpadmlDemoApplication {
	
	private static MessageRepository messageRepository; 
	
	private static MessageService messageService;

	public static void main(String[] args) {
		
		ApplicationContext context = SpringApplication.run(SpringDataJpadmlDemoApplication.class, args);
		
		messageRepository = context.getBean(MessageRepository.class); 
		messageService = context.getBean(MessageService.class);
		
		//testFindById(3l);
		//testInsert();
		//testUpdate();
		//testDelete();
		//testFindAll();
		
		  List<Message> messages= messageService.getMessageContainsHello();
		  
		  for(Message message:messages) {
		  System.out.println("Message name: "+message.getText());
		  
		  }
		 
		
	}
	
public static void testFindById(Long id) {
		
		Optional<Message> messageOptional =messageRepository.findById(id);
		
	Message message = messageOptional.get();
		
		System.out.println("Message name: "+message.getText());
		
		
		
		
	}



public static void testFindAll() {
	
	List<Message> messages =messageRepository.findAll();
	

for(Message message:messages) {
	System.out.println("Message name: "+message.getText());
	
}
	
	
	
	
	
	
}



public static void testInsert() {
	
	System.out.println("inside  testInsert");
	
	Message message = new Message();
	
	message.setId(100l);
	
	message.setText("All the glitters are not gold");
	
	messageRepository.save(message);
	
	List<Message> messages = messageRepository.findAll();
	
	for( Message m:messages) {
		
		System.out.println("message text: "+m.getText());
	}
	
	
}

public static void testUpdate() {
	
	System.out.println("inside testUpdate");
	
	Optional<Message> message = messageRepository.findById(100l);
	
	System.out.println("Before update");	
	System.out.println("message found for 100: "+message.get().getText());
	
	message.get().setText("All the glitters are not gold");
	
	Message msg = message.get();
	messageRepository.save(msg);
	System.out.println("After update");	
	
	message = messageRepository.findById(100l);
	
	System.out.println("message found for 100: "+message.get().getText());
}

public static void testDelete() {
	
	System.out.println("inside  testDelete");
	
	Optional<Message> message = messageRepository.findById(100l);
	
	System.out.println("Before delete");	
	System.out.println("message found for 100: "+message.get().getText());
	
	
	Message msg = message.get();
	messageRepository.delete(msg);
	System.out.println("After delete");	
	
	Optional<Message> message1 = messageRepository.findById(100l);
	System.out.println("message found for 100: "+message1);
}


}
